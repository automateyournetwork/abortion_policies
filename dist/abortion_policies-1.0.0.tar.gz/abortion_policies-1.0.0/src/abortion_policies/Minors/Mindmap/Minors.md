
# Minor Laws Per State
## Alabama
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Alaska
### Below Age: No
### Parental Requirements
#### Consent: No
#### Notification: No
#### Required: No
### Judicial Bypass Available: No
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Arizona
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Arkansas
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## California
### Below Age: No
### Parental Requirements
#### Consent: No
#### Notification: No
#### Required: No
### Judicial Bypass Available: No
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Colorado
### Below Age: 18
### Parental Requirements
#### Consent: No
#### Notification: True
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Connecticut
### Below Age: No
### Parental Requirements
#### Consent: No
#### Notification: No
#### Required: No
### Judicial Bypass Available: No
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Delaware
### Below Age: 16
### Parental Requirements
#### Consent: No
#### Notification: True
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## District of Columbia
### Below Age: No
### Parental Requirements
#### Consent: No
#### Notification: No
#### Required: No
### Judicial Bypass Available: No
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Florida
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: True
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: 2021-05-21T22:00:20.000Z</td>
## Georgia
### Below Age: 18
### Parental Requirements
#### Consent: No
#### Notification: True
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Hawaii
### Below Age: No
### Parental Requirements
#### Consent: No
#### Notification: No
#### Required: No
### Judicial Bypass Available: No
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Idaho
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Illinois
### Below Age: No
### Parental Requirements
#### Consent: No
#### Notification: No
#### Required: No
### Judicial Bypass Available: No
### Allows Minor to Consent: No
### Last Updated: 2022-06-03T16:56:26.000Z</td>
## Indiana
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Iowa
### Below Age: 18
### Parental Requirements
#### Consent: No
#### Notification: True
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Kansas
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 2
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Kentucky
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Louisiana
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Maine
### Below Age: No
### Parental Requirements
#### Consent: No
#### Notification: No
#### Required: No
### Judicial Bypass Available: No
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Maryland
### Below Age: 18
### Parental Requirements
#### Consent: No
#### Notification: True
#### Required: 1
### Judicial Bypass Available: No
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Massachusetts
### Below Age: 16
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: 2022-06-30T09:54:47.000Z</td>
## Michigan
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Minnesota
### Below Age: 18
### Parental Requirements
#### Consent: No
#### Notification: True
#### Required: 2
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Mississippi
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 2
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Missouri
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Montana
### Below Age: 18
### Parental Requirements
#### Consent: No
#### Notification: True
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: 2022-02-11T15:51:59.000Z</td>
## Nebraska
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Nevada
### Below Age: No
### Parental Requirements
#### Consent: No
#### Notification: No
#### Required: No
### Judicial Bypass Available: No
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## New Hampshire
### Below Age: 18
### Parental Requirements
#### Consent: No
#### Notification: True
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## New Jersey
### Below Age: No
### Parental Requirements
#### Consent: No
#### Notification: No
#### Required: No
### Judicial Bypass Available: No
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## New Mexico
### Below Age: No
### Parental Requirements
#### Consent: No
#### Notification: No
#### Required: No
### Judicial Bypass Available: No
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## New York
### Below Age: No
### Parental Requirements
#### Consent: No
#### Notification: No
#### Required: No
### Judicial Bypass Available: No
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## North Carolina
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## North Dakota
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 2
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Ohio
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Oklahoma
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: True
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Oregon
### Below Age: No
### Parental Requirements
#### Consent: No
#### Notification: No
#### Required: No
### Judicial Bypass Available: No
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Pennsylvania
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Rhode Island
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## South Carolina
### Below Age: 17
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## South Dakota
### Below Age: 18
### Parental Requirements
#### Consent: No
#### Notification: True
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Tennessee
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Texas
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: True
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Utah
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: True
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Vermont
### Below Age: No
### Parental Requirements
#### Consent: No
#### Notification: No
#### Required: No
### Judicial Bypass Available: No
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Virginia
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: True
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Washington
### Below Age: No
### Parental Requirements
#### Consent: No
#### Notification: No
#### Required: No
### Judicial Bypass Available: No
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## West Virginia
### Below Age: 18
### Parental Requirements
#### Consent: No
#### Notification: True
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Wisconsin
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: No
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>
## Wyoming
### Below Age: 18
### Parental Requirements
#### Consent: True
#### Notification: True
#### Required: 1
### Judicial Bypass Available: True
### Allows Minor to Consent: No
### Last Updated: No date available</td>