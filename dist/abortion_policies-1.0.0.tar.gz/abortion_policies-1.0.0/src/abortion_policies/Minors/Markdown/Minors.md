# Minors
| State | Below Age | Parental Consent Required | Parental Notification Required | Parents Required | Judicial Bypass Available | Allows Minor to Consent | Last Updated |
| ----- | --------- | ------------------------- | ------------------------------ | ---------------- | ------------------------- | ----------------------- | ------------ |
| Alabama | 18 | True | No | 1 | True | No | No date available |
| Alaska | No | No | No | No | No | No | No date available |
| Arizona | 18 | True | No | 1 | True | No | No date available |
| Arkansas | 18 | True | No | 1 | True | No | No date available |
| California | No | No | No | No | No | No | No date available |
| Colorado | 18 | No | True | 1 | True | No | No date available |
| Connecticut | No | No | No | No | No | No | No date available |
| Delaware | 16 | No | True | 1 | True | No | No date available |
| District of Columbia | No | No | No | No | No | No | No date available |
| Florida | 18 | True | True | 1 | True | No | 2021-05-21T22:00:20.000Z |
| Georgia | 18 | No | True | 1 | True | No | No date available |
| Hawaii | No | No | No | No | No | No | No date available |
| Idaho | 18 | True | No | 1 | True | No | No date available |
| Illinois | No | No | No | No | No | No | 2022-06-03T16:56:26.000Z |
| Indiana | 18 | True | No | 1 | True | No | No date available |
| Iowa | 18 | No | True | 1 | True | No | No date available |
| Kansas | 18 | True | No | 2 | True | No | No date available |
| Kentucky | 18 | True | No | 1 | True | No | No date available |
| Louisiana | 18 | True | No | 1 | True | No | No date available |
| Maine | No | No | No | No | No | No | No date available |
| Maryland | 18 | No | True | 1 | No | No | No date available |
| Massachusetts | 16 | True | No | 1 | True | No | 2022-06-30T09:54:47.000Z |
| Michigan | 18 | True | No | 1 | True | No | No date available |
| Minnesota | 18 | No | True | 2 | True | No | No date available |
| Mississippi | 18 | True | No | 2 | True | No | No date available |
| Missouri | 18 | True | No | 1 | True | No | No date available |
| Montana | 18 | No | True | 1 | True | No | 2022-02-11T15:51:59.000Z |
| Nebraska | 18 | True | No | 1 | True | No | No date available |
| Nevada | No | No | No | No | No | No | No date available |
| New Hampshire | 18 | No | True | 1 | True | No | No date available |
| New Jersey | No | No | No | No | No | No | No date available |
| New Mexico | No | No | No | No | No | No | No date available |
| New York | No | No | No | No | No | No | No date available |
| North Carolina | 18 | True | No | 1 | True | No | No date available |
| North Dakota | 18 | True | No | 2 | True | No | No date available |
| Ohio | 18 | True | No | 1 | True | No | No date available |
| Oklahoma | 18 | True | True | 1 | True | No | No date available |
| Oregon | No | No | No | No | No | No | No date available |
| Pennsylvania | 18 | True | No | 1 | True | No | No date available |
| Rhode Island | 18 | True | No | 1 | True | No | No date available |
| South Carolina | 17 | True | No | 1 | True | No | No date available |
| South Dakota | 18 | No | True | 1 | True | No | No date available |
| Tennessee | 18 | True | No | 1 | True | No | No date available |
| Texas | 18 | True | True | 1 | True | No | No date available |
| Utah | 18 | True | True | 1 | True | No | No date available |
| Vermont | No | No | No | No | No | No | No date available |
| Virginia | 18 | True | True | 1 | True | No | No date available |
| Washington | No | No | No | No | No | No | No date available |
| West Virginia | 18 | No | True | 1 | True | No | No date available |
| Wisconsin | 18 | True | No | 1 | True | No | No date available |
| Wyoming | 18 | True | True | 1 | True | No | No date available |