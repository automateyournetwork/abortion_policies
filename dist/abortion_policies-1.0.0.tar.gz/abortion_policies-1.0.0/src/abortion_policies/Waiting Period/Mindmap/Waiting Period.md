
# Waiting Period Per State
## Alabama
### Hours: 48
### Counseling Visits: 1
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## Alaska
### Hours: N/A
### Counseling Visits: 1
### Exception Health: N/A
### Notes: N/A
### Last Updated: 2022-02-15T21:04:41.000Z</td>
## Arizona
### Hours: 24
### Counseling Visits: 2
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## Arkansas
### Hours: 72
### Counseling Visits: 2
### Exception Health: N/A
### Notes: N/A
### Last Updated: 2019-11-13T12:13:26.000Z</td>
## Florida
### Hours: 24
### Counseling Visits: 2
### Exception Health: N/A
### Notes: N/A
### Last Updated: 2022-04-04T14:57:11.000Z</td>
## Georgia
### Hours: 24
### Counseling Visits: 1
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## Idaho
### Hours: 24
### Counseling Visits: 1
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## Indiana
### Hours: 18
### Counseling Visits: 2
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## Iowa
### Hours: 24
### Counseling Visits: 1
### Exception Health: N/A
### Notes: N/A
### Last Updated: 2022-06-18T17:06:11.000Z</td>
## Kansas
### Hours: 24
### Counseling Visits: 1
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## Kentucky
### Hours: 24
### Counseling Visits: 2
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## Louisiana
### Hours: 72
### Counseling Visits: 2
### Exception Health: N/A
### Notes: N/A
### Last Updated: 2022-06-16T13:15:50.000Z</td>
## Michigan
### Hours: 24
### Counseling Visits: 1
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## Minnesota
### Hours: 24
### Counseling Visits: 1
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## Mississippi
### Hours: 24
### Counseling Visits: 2
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## Missouri
### Hours: 72
### Counseling Visits: 2
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## Nebraska
### Hours: 24
### Counseling Visits: 1
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## North Carolina
### Hours: 72
### Counseling Visits: 1
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## North Dakota
### Hours: 24
### Counseling Visits: 1
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## Ohio
### Hours: 24
### Counseling Visits: 2
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## Oklahoma
### Hours: 72
### Counseling Visits: 1
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## Pennsylvania
### Hours: 24
### Counseling Visits: 1
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## South Carolina
### Hours: 24
### Counseling Visits: 1
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## South Dakota
### Hours: 72
### Counseling Visits: 2
### Exception Health: N/A
### Notes: Weekends and holidays do not count towards the 72-hour waiting period.
### Last Updated: No date available</td>
## Tennessee
### Hours: 48
### Counseling Visits: 2
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## Texas
### Hours: 24
### Counseling Visits: 2
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## Utah
### Hours: 72
### Counseling Visits: 2
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## Virginia
### Hours: N/A
### Counseling Visits: N/A
### Exception Health: N/A
### Notes: N/A
### Last Updated: 2020-07-06T15:57:47.000Z</td>
## West Virginia
### Hours: 24
### Counseling Visits: 1
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>
## Wisconsin
### Hours: 24
### Counseling Visits: 2
### Exception Health: N/A
### Notes: N/A
### Last Updated: No date available</td>