
# Insurance Coverage Per State
## Alabama
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## Alaska
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Last Updated: No date available
## Arizona
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: Major Bodily Function
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: 2021-05-21T22:18:09.000Z
## Arkansas
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## California
### Requires Coverage: True
### Private Coverage
#### No Restrictions: No exception
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Last Updated: 2019-11-13T12:10:29.000Z
## Colorado
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## Connecticut
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Last Updated: No date available
## Delaware
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## District of Columbia
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## Florida
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## Georgia
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: Major Bodily Function
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## Hawaii
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Last Updated: No date available
## Idaho
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## Illinois
### Requires Coverage: True
### Private Coverage
#### No Restrictions: No exception
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Last Updated: 2019-07-02T11:35:00.000Z
## Indiana
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: Major Bodily Function
#### Fetal: No exception
#### Rape or Incest: True
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: Major Bodily Function
#### Fetal: No exception
#### Rape or Incest: True
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: Physical
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## Iowa
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: Serious fetal anomaly
#### Rape or Incest: True
### Last Updated: No date available
## Kansas
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: 2021-05-21T22:14:13.000Z
## Kentucky
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## Louisiana
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: True
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## Maine
### Requires Coverage: True
### Private Coverage
#### No Restrictions: No exception
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Last Updated: 2019-11-13T12:09:56.000Z
## Maryland
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Last Updated: No date available
## Massachusetts
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Last Updated: No date available
## Michigan
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## Minnesota
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Last Updated: No date available
## Mississippi
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: Serious fetal anomaly
#### Rape or Incest: True
### Last Updated: No date available
## Missouri
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## Montana
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Last Updated: No date available
## Nebraska
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## Nevada
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## New Hampshire
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## New Jersey
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Last Updated: No date available
## New Mexico
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Last Updated: No date available
## New York
### Requires Coverage: True
### Private Coverage
#### No Restrictions: No exception
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Last Updated: 2019-11-13T12:10:25.000Z
## North Carolina
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## North Dakota
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## Ohio
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## Oklahoma
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## Oregon
### Requires Coverage: True
### Private Coverage
#### No Restrictions: No exception
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: True
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Last Updated: No date available
## Pennsylvania
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## Rhode Island
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## South Carolina
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## South Dakota
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: Major Bodily Function
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Last Updated: No date available
## Tennessee
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: True
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## Texas
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: Major Bodily Function
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: Major Bodily Function
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## Utah
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: Major Bodily Function
#### Fetal: Lethal fetal anomaly
#### Rape or Incest: True
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: Major Bodily Function
#### Fetal: Lethal fetal anomaly
#### Rape or Incest: True
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: Physical
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available
## Vermont
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Last Updated: No date available
## Virginia
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: Serious fetal anomaly
#### Rape or Incest: True
### Last Updated: 2021-05-21T22:14:49.000Z
## Washington
### Requires Coverage: True
### Private Coverage
#### No Restrictions: No exception
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Last Updated: No date available
## West Virginia
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: Major Bodily Function
#### Fetal: Serious fetal anomaly
#### Rape or Incest: True
### Last Updated: No date available
## Wisconsin
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: No exception
#### Life: True
#### Health: Physical
#### Fetal: No exception
#### Rape or Incest: True
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: Physical
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: 2021-05-21T22:13:01.000Z
## Wyoming
### Requires Coverage: No exception
### Private Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
### Exchange Coverage
#### No Restrictions: True
#### Life: No exception
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: No exception
#### Forbids Coverage: No exception
### Medicaid Coverage
#### Provider Patient Decision: No exception
#### Life: True
#### Health: No exception
#### Fetal: No exception
#### Rape or Incest: True
### Last Updated: No date available