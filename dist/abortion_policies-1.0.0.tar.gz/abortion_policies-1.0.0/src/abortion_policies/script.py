from .abortion_policies import cli
def run():
    cli()